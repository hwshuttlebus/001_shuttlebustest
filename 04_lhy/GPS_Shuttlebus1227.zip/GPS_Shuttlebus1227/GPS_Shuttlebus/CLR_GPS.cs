﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Threading;
using System.Globalization;
namespace WincePda.Chinese.GPS
{
    class CLR_GPS
    {
#region 
        [DllImport("DeviceAPI.dll", EntryPoint = "Gps_init")]
        private static extern bool Gps_init();

        [DllImport("DeviceAPI.dll", EntryPoint = "Gps_free")]
        private static extern bool Gps_free();


        [DllImport("DeviceAPI.dll", EntryPoint = "Gps_close_serial")]
        private static extern bool Gps_close_serial();

        [DllImport("DeviceAPI.dll", EntryPoint = "Gps_open_serial")]
        private static extern int Gps_open_serial();


        [DllImport("DeviceAPI.dll", EntryPoint = "Gps_send_data")]
        private static extern int Gps_send_data(byte[] data,int length);


        [DllImport("DeviceAPI.dll", EntryPoint = "Gps_receive_data")]
        private static extern int Gps_receive_data(byte[] data,int length);

        /// <summary>
        ///  端口选择，用于端口间的相互切换；  注：在使用COM4的时候才需要调用此函数 
        /// </summary>
        /// <param name="iPort">端口号:0 RFID；1 外接串口；2 Barcode；3 GPS；</param>
        [DllImport("DeviceAPI.dll", EntryPoint = "SerialPortSwitch_Ex")]
        private static extern bool SerialPortSwitch_Ex(int iPort);



        /// <summary>
        /// GPS模块通电
        /// </summary>
        /// <returns></returns>
        public bool PowerOn()
        {
            return Gps_init();
        }

        /// <summary>
        /// GPS模块断电
        /// </summary>
        public bool PowerOff()
        {
            return Gps_free();
        }
        /// <summary>
        ///打开GPS串口   Gps_module_open返回0表示打开GPS的串口失败，返回1表示打开成功，返回2表示已经打开，
        /// </summary>
        public bool Gps_OpenSerial()
        {
            try
            {
                int result = 0;
                result = Gps_open_serial();
                if (result == 0)
                {
                    System.Windows.Forms.MessageBox.Show("Open the serial failure!");
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Open the serial failure:" + ex.Message);
                return false;
            }
        }
        /// <summary>
        ///关闭GPS串口
        /// </summary>
        public bool Gps_CloseSerial()
        {
            return Gps_close_serial();
        }
        /// <summary>
        ///发送数据
        /// </summary>
        public int Gps_SendData(byte[] data, int length)
        {
            return Gps_send_data(data, length);
        }
        /// <summary>
        ///得到数据
        /// </summary>
        public int Gps_ReceiveData(byte[] data,int length)
        {
            return Gps_receive_data(data, length);
        }
#endregion




        CLR_Regex gpsRegex;


        public struct gpsItem
        {
            /// <summary>
            /// 纬度
            /// </summary>
            public float lati;

            /// <summary>
            /// 经度
            /// </summary>
            public float longi;

            /// <summary>
            /// 可视卫星数量
            /// </summary>
            public string allSatellite;

            /// <summary>
            /// 可用卫星数量
            /// </summary>
            public string useSatellite;

            /// <summary>
            /// 海拔
            /// </summary>
            public string altitude;

            /// <summary>
            /// UTC时间。当地时间等于UTC时间+时区。例如：北京时间=UTC时间 + 8小时
            /// </summary>
            public string UTC_time;

            /// <summary>
            /// 日期
            /// </summary>
            public string currDate;
        }
 
#region 


 



#endregion
    

        /// <summary>
        /// GPS基础类，包含了模块电源操作和GPS数据的解析函数
        /// </summary>
        public CLR_GPS()
        {
            gpsRegex = new CLR_Regex();
        }

    


        /// <summary>
        /// 解析GPS数据包
        /// </summary>
        /// <param name="scr">数据包内容</param>
        /// <param name="nItem">存储解析结果</param>
        private  void AnalysisGPGGA(string scr,ref gpsItem nItem)
        {
            string altitude = string.Empty;
            string[] fields = scr.Split(',');
          
            if (fields.Length>10)
            {
                string num = fields[7].Trim();
                if (num.Length > 0 && gpsRegex.isNumber(num))
                {
                    nItem.useSatellite = num;
                    
                }
                if (fields[9].Trim().Length > 0)
                {
                    nItem.altitude = fields[9].Trim();
                }
            }                         
        }


        /// <summary>
        /// 解析GPRMC数据包
        /// </summary>
        /// <param name="scr"></param>
        /// <param name="nitem"></param>
        /// <returns></returns>
        private bool AnalysisGPRMC(string scr,ref gpsItem nitem)
        {
            #region
            /*
            int latiDegree = 400, longiDegree = 400;
            float latiMinute = 400, longiMinute = 400, speedTemp = 0, directionTemp = 0;
            string statusTemp = string.Empty;
            float latitudeTemp = 400, longitudeTemp = 400;
            bool paramChanged = false;

            //bool isNortHemisphere = true;
            //bool isEastHemisphere=true;
            string time = string.Empty;

            string[] fields = scr.Split(',');

            if (fields.GetLength(0) < 12)
                return false;
            // 状态

            string[] utc = fields[1].Trim().Split('.');


            if (utc[0].Trim().Length == 6)
            {
                nitem.UTC_time = utc[0].Trim();             
            }

            if (fields[2]=="A")
            {
                statusTemp = fields[2];
            }
            // Lati 
            if (fields[3].Length > 5)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[3], @"^[0-9]+[.]?([\d]+)?").Value == fields[3])
                {
                    latiDegree = Convert.ToInt32(fields[3].Substring(0, 2), 10);
                    latiMinute = Convert.ToSingle(fields[3].Substring(2, fields[3].Length - 2));
                    paramChanged = true;
                }
            }
            // NSHemisphere  NSHemisphere     南北半球
            if (fields[4].Length == 1)
            {
                //'s' 'S' 
                if (string.Equals(fields[4], "S", StringComparison.CurrentCultureIgnoreCase))
                {
                    //isNortHemisphere = false;   //南半球
                    latitudeTemp = -latitudeTemp;
                }
            }
            // long 
            if (fields[5].Length > 5)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[5], @"^[0-9]+[.]?([\d]+)?").Value == fields[5])
                {
                    longiDegree = Convert.ToInt32(fields[5].Substring(0, 3), 10);
                    longiMinute = Convert.ToSingle(fields[5].Substring(3, fields[5].Length - 3));
                    paramChanged = true;
                }
            }
            // EWHemisphere    东经 西经
            if (fields[6].Length == 1)
            {
                //'w' 'W' 
                if (string.Equals(fields[6], "W", StringComparison.CurrentCultureIgnoreCase))
                {
                    //isEastHemisphere=false; //西半球
                    longitudeTemp = -longitudeTemp;
                }
            }
            // speed    速率
            if (fields[7].Length > 2)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[7], @"^[0-9]+[.]?([\d]+)?").Value == fields[7])
                {
                    speedTemp = (float)(Convert.ToSingle(fields[7]) * 1.852);
                    paramChanged = true;
                }
            }
            // direction   地面航向 正北为零度
            if (fields[8].Length > 2)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[8], @"^[0-9]+[.]?([\d]+)?").Value == fields[8])
                {
                    directionTemp = Convert.ToSingle(fields[8]);
                    paramChanged = true;
                }
            }

            if (fields[9].Trim().Length==6)
            {          
                nitem.currDate=trandforDate(fields[9].Trim());
            }
            if ((latiDegree != 400) && (latiMinute != (float)400.0))
            {
                latitudeTemp = (float)(latiDegree + latiMinute / 60.0);
            }
            if ((longiDegree != 400) && (longiMinute != (float)400.0))
            {
                longitudeTemp = (float)(longiDegree + longiMinute / 60.0);
            }
            if (paramChanged)
            {
                nitem.lati = latitudeTemp;
                nitem.longi = longitudeTemp;
                return true;            
            }
            else
                return false;
             * */
            #endregion
            //  scr="GNRMC,064539.00,A,2234.616901,N,11355.128267,E,0.0,,151212,,,A*62";
            int latiDegree = 400, longiDegree = 400;
            float latiMinute = 400, longiMinute = 400, speedTemp = 0, directionTemp = 0;

            string statusTemp = string.Empty;
            float latitudeTemp = 400, longitudeTemp = 400;

            bool paramChanged = false;

            //bool isNortHemisphere = true;
            //bool isEastHemisphere=true;
            string time = string.Empty;

            string[] fields = scr.Split(',');

            if (fields.GetLength(0) < 12)
                return false;
            // 状态

            string[] utc = fields[1].Trim().Split('.');

            CultureInfo ci = (CultureInfo)CultureInfo.CurrentCulture.Clone();
            ci.NumberFormat.CurrencyDecimalSeparator = ".";

            if (utc[0].Trim().Length == 6)
            {
                nitem.UTC_time = utc[0].Trim();
            }

            if (fields[2] == "A")
            {
                statusTemp = fields[2];
            }
            // Lati 
            if (fields[3].Length > 5)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[3], @"^[0-9]+[.]?([\d]+)?").Value == fields[3])
                {
                    //pcSqlite.myFile.Add_New_Note(@"\field3.txt", fields[3].ToString()+"\r\n");      
                    latiDegree = Convert.ToInt32(fields[3].Substring(0, 2), 10);
                    //latiMinute = Convert.ToSingle(fields[3].Substring(2,fields[3].Length -2));
                    latiMinute = float.Parse(fields[3].Substring(2, fields[3].Length - 2), NumberStyles.Any, ci);

                    paramChanged = true;
                }
            }
            // NSHemisphere  NSHemisphere     南北半球
            if (fields[4].Length == 1)
            {
                //'s' 'S' 
                if (string.Equals(fields[4], "S", StringComparison.CurrentCultureIgnoreCase))
                {
                    //isNortHemisphere = false;   //南半球
                    latitudeTemp = -latitudeTemp;
                    //pcSqlite.myFile.Add_New_Note(@"\latitudeTemp.txt", latitudeTemp.ToString());
                }
            }
            // long 
            if (fields[5].Length > 5)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[5], @"^[0-9]+[.]?([\d]+)?").Value == fields[5])
                {
                    longiDegree = Convert.ToInt32(fields[5].Substring(0, 3), 10);
                    longiMinute = float.Parse(fields[5].Substring(3, fields[5].Length - 3), NumberStyles.Any, ci);// Convert.ToSingle(fields[5].Substring(3, fields[5].Length - 3));

                    paramChanged = true;
                }
            }
            // EWHemisphere    东经 西经
            if (fields[6].Length == 1)
            {
                //'w' 'W' 
                if (string.Equals(fields[6], "W", StringComparison.CurrentCultureIgnoreCase))
                {
                    //isEastHemisphere=false; //西半球
                    longitudeTemp = -longitudeTemp;
                    // pcSqlite.myFile.Add_New_Note(@"\longitudeTemp.txt", longitudeTemp.ToString());
                }
            }
            // speed    速率
            if (fields[7].Length > 2)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[7], @"^[0-9]+[.]?([\d]+)?").Value == fields[7])
                {
                    speedTemp = float.Parse(fields[7], NumberStyles.Any, ci) * float.Parse("1.852", NumberStyles.Any, ci); ;// (float)(Convert.ToSingle(fields[7]) * 1.852);

                    paramChanged = true;
                }
            }
            // direction   地面航向 正北为零度
            if (fields[8].Length > 2)
            {
                if (System.Text.RegularExpressions.Regex.Match(fields[8], @"^[0-9]+[.]?([\d]+)?").Value == fields[8])
                {
                    directionTemp = float.Parse(fields[8], NumberStyles.Any, ci); //Convert.ToSingle(fields[8]);

                    paramChanged = true;
                }
            }

            if (fields[9].Trim().Length == 6)
            {
                nitem.currDate = trandforDate(fields[9].Trim());
            }
            if ((latiDegree != 400) && (latiMinute != (float)400.0))
            {
                latitudeTemp = (float)(latiDegree + float.Parse(latiMinute.ToString(), NumberStyles.Any, ci) / float.Parse("60.0", NumberStyles.Any, ci));

            }
            if ((longiDegree != 400) && (longiMinute != (float)400.0))
            {
                longitudeTemp = (float)(longiDegree + float.Parse(longiMinute.ToString(), NumberStyles.Any, ci) / float.Parse("60.0", NumberStyles.Any, ci));
            }
            if (paramChanged)
            {
                nitem.lati = latitudeTemp;
                nitem.longi = longitudeTemp;
                return true;
            }
            else
                return false;
        }


        /// <summary>
        /// data  for date  将GPS数据转换成日期
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        string trandforDate(string date)
        {
            return "20"+date.Substring(4, 2) + "-" + date.Substring(2, 2) + "-" + date.Substring(0, 2);
        }



        /// <summary>
        /// 解析可视卫星数量
        /// </summary>
        /// <param name="scr"></param>
        void AnalysisGPGSV(string scr,ref gpsItem nItem)
        {
            string[] fields = scr.Split(',');

            if (fields.Length>4)
            {
                string AllNum = fields[3].Trim();

                if (AllNum.Length > 0 && gpsRegex.isNumber(AllNum))
                {
                    //可视卫星数量
                    nItem.allSatellite = fields[3];
                }
               
            }

            // 状态
        }

        /// <summary>
        /// 解析GPS数据
        /// </summary>
        /// <param name="sGpsData"></param>
        public gpsItem AnalysisGPSData(string sGpsData, ref gpsItem nitem)
        {
            //getFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+"\r\n"+sGpsData);

            string[] gpsDataSplit = sGpsData.Trim().Split('$');
                for (int k = 0; k < gpsDataSplit.Length;k++ )
                {
                    if (k > 8)//可能数据行比较多，所以只解析前9行数据 
                        break;
                    if (gpsDataSplit[k].StartsWith("GPRMC"))
                    {
                        AnalysisGPRMC(gpsDataSplit[k], ref nitem);
                    }
                    else if (gpsDataSplit[k].StartsWith("GPVTG"))
                    {
                        //AnalysisGPVTG(gps);
                    }
                    else if (gpsDataSplit[k].StartsWith("GPGGA"))
                    {
                        AnalysisGPGGA(gpsDataSplit[k], ref nitem);
                    }
                    else if (gpsDataSplit[k].StartsWith("GPGSV"))
                    {
                        AnalysisGPGSV(gpsDataSplit[k], ref nitem);
                    }
                    else if (gpsDataSplit[k].StartsWith("GPGLL"))
                    {

                    }
                }
            return nitem;
        }

        //private void file(string str)
        //{
        //    string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)+"\\GPS.txt";
        //    try
        //    {
        //        if (!System.IO.File.Exists(path))
        //        {
        //            System.IO.FileStream filewriter = new System.IO.FileStream(path, System.IO.FileMode.Create, System.IO.FileAccess.Write);
        //            System.IO.StreamWriter sw = new System.IO.StreamWriter(filewriter, Encoding.ASCII);

        //            sw.WriteLine(str);
        //            sw.Close();
        //            filewriter.Close();
        //        }
        //        else
        //        {
        //            System.IO.FileStream fileWriter = new System.IO.FileStream(path, System.IO.FileMode.Append, System.IO.FileAccess.Write);
        //            System.IO.StreamWriter sw = new System.IO.StreamWriter(fileWriter, Encoding.ASCII);
        //            sw.WriteLine(str);
        //            sw.Close();
        //            fileWriter.Close();
        //        }
        //    }
        //    catch (System.Exception ex)
        //    {
            	
        //    }

            
        //}
 

    }
}
