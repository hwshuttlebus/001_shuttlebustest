﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Forms;
using WincePda.Chinese.GPS;
using System.Runtime.InteropServices;

namespace WincePda.Chinese.GPS
{
    static class Program
    {
        [DllImport("coredll.dll")]
        public static extern IntPtr CreateEvent(IntPtr lpEventAttributes, [MarshalAs(UnmanagedType.Bool)]bool bManualReset, [MarshalAs(UnmanagedType.Bool)]bool bInitialState, [MarshalAs(UnmanagedType.LPWStr)]string lpName);
        [DllImport("coredll.dll", SetLastError = true)]
        public static extern Int32 WaitForSingleObject(IntPtr Handle, Int32 Wait);
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [MTAThread]
        static void Main()
        {

            IntPtr hSingleRun = CreateEvent(IntPtr.Zero, false, true, "GPS");
            if (WaitForSingleObject(hSingleRun, 0) != 0)
            {
                WincePda.UIInfo.GetLanguageType();
                if (WincePda.UIInfo.languaeType == WincePda.UIInfo.LanguageType.EN)
                    MessageBox.Show("Programs are running!");
                else
                    MessageBox.Show("重复打开!");
                return;
            }
            Application.Run(new GPS_bus());
        }
    }
}