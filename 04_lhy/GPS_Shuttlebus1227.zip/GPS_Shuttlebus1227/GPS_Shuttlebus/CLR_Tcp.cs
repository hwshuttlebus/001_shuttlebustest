﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.IO;
//using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
//using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Runtime.InteropServices;

namespace GPS_Shuttlebus
{
    class CLR_socket
    {
        private static int m_maxpacket = 1024 * 4;

        #region Client connection


        public static Socket ConnectSocket(TcpClient tcpclient, IPAddress ip_add, int port)
        {
            try
            {
                tcpclient.Connect(ip_add, port);
                return tcpclient.Client;
            }
            catch
            {
                return null;
            }
        }
        public static NetworkStream ConnectStream(TcpClient tcp_Client, IPAddress ipadd, int port)
        {
            try
            {
                tcp_Client.Connect(ipadd, port);
                return tcp_Client.GetStream();
            }
            catch
            {
                return null;
            }
        }

        public static void CloseConnect(TcpClient tcp_Client)
        {
            try
            {
                tcp_Client.Close();
            }
            catch
            {
            }
        }
        #endregion


        #region Socket send data
        /// <summary>
        /// 发送固定长度消息
        /// 发送字节数不能大于int型最大值
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="msg"></param>
        /// <returns>返回发送字节个数</returns>
        public static int Send_Data(Socket socket, byte[] msg)
        {
            int size = msg.Length; //要发送字节长度
            int offset = 0;     //已经发送长度
            int dataleft = size;  //剩下字符
            int senddata = m_maxpacket; //每次发送大小
            while (true)
            {
                //如过剩下的字节数 小于 每次发送字节数
                if (dataleft < senddata)
                {
                    senddata = dataleft;
                }
                int count = socket.Send(msg, offset, senddata, SocketFlags.None);
                offset += count;
                dataleft -= count;
                if (offset == size)
                {
                    break;
                }
            }
            return offset;
        }
        /// <summary>
               





        #endregion
        #region  tcp
        private TcpClient ConnectServer()
        {
            TcpClient client = new TcpClient();
            string hostName = System.Net.Dns.GetHostName();
            System.Net.IPHostEntry myIp = System.Net.Dns.GetHostEntry(hostName);
            var address = (from h in myIp.AddressList
                           where h.AddressFamily == AddressFamily.InterNetwork
                           select h).First();
            try
            {
                client.Connect(address.ToString(), 9000);

            }
            catch
            {
                client = null;
            }
            return client;

        }

        public void timerBusTcp_sender(string gps_Lon, string gps_Lat)
        {
            TcpClient client = ConnectServer();
            NetworkStream clientStream = client.GetStream();
            byte[] requestBuffer = Encoding.ASCII.GetBytes(gps_Lon + gps_Lat);

            clientStream.Write(requestBuffer, 0, requestBuffer.Length);
            clientStream.Close();
            client.Close();
        }

        #endregion

        #region  http1.0

        public  void timerBusHttp_sender(string gps_Lon, string gps_Lat)
        {
            string userName = "username";
            string passWord = "password";
            string URL = "url";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
            request.Credentials = new NetworkCredential(userName, passWord);
            request.ProtocolVersion = HttpVersion.Version10;

            request.Method = "POST";

            byte[] requestBuffer = Encoding.ASCII.GetBytes(gps_Lon + gps_Lat);

            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(requestBuffer, 0, requestBuffer.Length);
            }
            
        }
        #endregion


    }
}
