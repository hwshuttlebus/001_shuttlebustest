﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
namespace WincePda
{
    class CLR_Regex
    {

        /// <summary>
        /// is number ?  是否全是数字
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool isNumber(string msg)
        {
          
            if (Regex.Match(msg, "^[0-9]*$").Value == msg)
            {
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// is hex 判断是否全是十六进制数
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static bool isHex(string msg)
        {

            if (Regex.Match(msg, "^[0-9a-fA-F]*$").Value == msg)
            {
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// is real   是否为实数
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool isRealData(string msg)
        {
            if (msg.StartsWith("-"))
            {
                msg = msg.Substring(1);
            }
            if (Regex.Match(msg, "^[0-9]+(.[0-9]+)$").Value == msg)
            {
                return true;
            }
            else
                return false;

        }
        public static PDADeviceType pdaDeviceType = PDADeviceType.Unknown;
        /// <summary>
        /// 系统版本
        /// </summary>
        public enum PDADeviceType
        {
            C5000,
            C3000,
            C2000,
            Unknown

        }
        /// <summary>
        /// d得到系统版本号
        /// </summary>
        /// <returns></returns>
        public static PDADeviceType GetSystemVersion()
        {
            string sysVersion = (string)Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\ControlPanel\\SystemVersion", "ProductType", "C5");
            if (sysVersion == "C3")
                pdaDeviceType = PDADeviceType.C3000;
            else if (sysVersion == "C2")
                pdaDeviceType = PDADeviceType.C2000;
            else
                pdaDeviceType = PDADeviceType.C5000;
            return pdaDeviceType;
        }

    }
}
