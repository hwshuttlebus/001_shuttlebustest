﻿namespace WincePda.Chinese.GPS
{
    partial class GPS_bus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelLo = new System.Windows.Forms.Label();
            this.labelLa = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.textBoxDate = new System.Windows.Forms.TextBox();
            this.textBoxTime = new System.Windows.Forms.TextBox();
            this.textBoxLa = new System.Windows.Forms.TextBox();
            this.textBoxLo = new System.Windows.Forms.TextBox();
            this.labelTime = new System.Windows.Forms.Label();
            this.btnGet = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.gps_Status = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer();
            this.timerTcp = new System.Windows.Forms.Timer();
            this.timerShowData = new System.Windows.Forms.Timer();
            this.textBox_IP = new System.Windows.Forms.TextBox();
            this.getIPbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelLo
            // 
            this.labelLo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.labelLo.Location = new System.Drawing.Point(24, 90);
            this.labelLo.Name = "labelLo";
            this.labelLo.Size = new System.Drawing.Size(68, 20);
            this.labelLo.Text = "经度:";
            // 
            // labelLa
            // 
            this.labelLa.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.labelLa.Location = new System.Drawing.Point(24, 132);
            this.labelLa.Name = "labelLa";
            this.labelLa.Size = new System.Drawing.Size(57, 20);
            this.labelLa.Text = "纬度:";
            // 
            // labelDate
            // 
            this.labelDate.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.labelDate.Location = new System.Drawing.Point(24, 15);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(40, 20);
            this.labelDate.Text = "日期:";
            // 
            // textBoxDate
            // 
            this.textBoxDate.Location = new System.Drawing.Point(87, 9);
            this.textBoxDate.Name = "textBoxDate";
            this.textBoxDate.Size = new System.Drawing.Size(101, 23);
            this.textBoxDate.TabIndex = 21;
            // 
            // textBoxTime
            // 
            this.textBoxTime.Location = new System.Drawing.Point(87, 43);
            this.textBoxTime.Name = "textBoxTime";
            this.textBoxTime.Size = new System.Drawing.Size(101, 23);
            this.textBoxTime.TabIndex = 22;
            // 
            // textBoxLa
            // 
            this.textBoxLa.Location = new System.Drawing.Point(87, 129);
            this.textBoxLa.Multiline = true;
            this.textBoxLa.Name = "textBoxLa";
            this.textBoxLa.Size = new System.Drawing.Size(101, 23);
            this.textBoxLa.TabIndex = 23;
            // 
            // textBoxLo
            // 
            this.textBoxLo.Location = new System.Drawing.Point(87, 87);
            this.textBoxLo.Name = "textBoxLo";
            this.textBoxLo.Size = new System.Drawing.Size(101, 23);
            this.textBoxLo.TabIndex = 24;
            // 
            // labelTime
            // 
            this.labelTime.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.labelTime.Location = new System.Drawing.Point(25, 49);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(39, 17);
            this.labelTime.Text = "UTC:";
            // 
            // btnGet
            // 
            this.btnGet.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnGet.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.btnGet.Location = new System.Drawing.Point(25, 204);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(67, 25);
            this.btnGet.TabIndex = 27;
            this.btnGet.Text = "获取数据";
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnStop.Enabled = false;
            this.btnStop.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.btnStop.Location = new System.Drawing.Point(25, 245);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(67, 25);
            this.btnStop.TabIndex = 28;
            this.btnStop.Text = "停止";
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // gps_Status
            // 
            this.gps_Status.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.gps_Status.Location = new System.Drawing.Point(24, 164);
            this.gps_Status.Name = "gps_Status";
            this.gps_Status.Size = new System.Drawing.Size(100, 20);
            this.gps_Status.Text = "状态:";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timerTcp
            // 
            this.timerTcp.Interval = 500;
            this.timerTcp.Tick += new System.EventHandler(this.timerTcp_Tick);
            // 
            // timerShowData
            // 
            this.timerShowData.Interval = 500;
            this.timerShowData.Tick += new System.EventHandler(this.timerShowData_Tick);
            // 
            // textBox_IP
            // 
            this.textBox_IP.Location = new System.Drawing.Point(107, 190);
            this.textBox_IP.Multiline = true;
            this.textBox_IP.Name = "textBox_IP";
            this.textBox_IP.Size = new System.Drawing.Size(144, 128);
            this.textBox_IP.TabIndex = 33;
            this.textBox_IP.TextChanged += new System.EventHandler(this.textBox_IP_TextChanged);
            // 
            // getIPbutton
            // 
            this.getIPbutton.Location = new System.Drawing.Point(116, 158);
            this.getIPbutton.Name = "getIPbutton";
            this.getIPbutton.Size = new System.Drawing.Size(72, 20);
            this.getIPbutton.TabIndex = 34;
            this.getIPbutton.Text = "获取IP";
            this.getIPbutton.Click += new System.EventHandler(this.getIPbutton_Click);
            // 
            // GPS_bus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(281, 353);
            this.Controls.Add(this.getIPbutton);
            this.Controls.Add(this.textBox_IP);
            this.Controls.Add(this.gps_Status);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.textBoxLo);
            this.Controls.Add(this.textBoxLa);
            this.Controls.Add(this.textBoxTime);
            this.Controls.Add(this.textBoxDate);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.labelLa);
            this.Controls.Add(this.labelLo);
            this.Name = "GPS_bus";
            this.Text = "GPS_bus";
            this.Click += new System.EventHandler(this.btnStop_Click);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelLo;
        private System.Windows.Forms.Label labelLa;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.TextBox textBoxDate;
        private System.Windows.Forms.TextBox textBoxTime;
        private System.Windows.Forms.TextBox textBoxLa;
        private System.Windows.Forms.TextBox textBoxLo;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label gps_Status;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timerTcp;
        private System.Windows.Forms.Timer timerShowData;
        private System.Windows.Forms.TextBox textBox_IP;
        private System.Windows.Forms.Button getIPbutton;
    }
}

