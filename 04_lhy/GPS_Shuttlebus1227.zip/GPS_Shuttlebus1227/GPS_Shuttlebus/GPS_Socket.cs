﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace WincePda.Chinese.GPS
{
    class GPS_Socket
    {
        /// <summary>
        /// 判断是否已经存在链接
        /// </summary>
        /// <returns></returns>
        /*  bool isThereConnect()
          {
              if (isGPRSNet())
              {
                  bool res = false;
                  int n = 0;

                  while (!res && n < currCreat.Count)
                  {
                      res = gprs.GPRSIsCon(currCreat[n]);
                      if (res)
                      {
                          nameC = currCreat[n];
                      }
                      n += 1;
                  }

                  return res;
              }
              else
              {
                  bool res = false;
                  int n = 0;

                  while (!res && n < currCreat.Count)
                  {
                      res = gprs.GPRSIsCon(currCreat[n]);
                      if (res)
                      {
                          gprs.disConnect(currCreat[n]);
                      }
                      n += 1;

                  }
                  return false;
              }

        
          }*/
        /// <summary>
        /// 读取DNS信息，判断当前的dns的ip信息。如果是127.0.0.1表示没有网络，如果都是192.168打头的，表示当前连接不是gprs。如果有192.168.55.101，那么肯定是与PC同步了。
        /// </summary>
        /// <returns></returns>
       /* public string isGPRSNet()
        {
            string hostName = System.Net.Dns.GetHostName();
            System.Net.IPHostEntry myIp = System.Net.Dns.GetHostEntry(hostName);

            System.Net.IPAddress[] ipList = myIp.AddressList;

            if (ipList.Length == 0)
            {
                return null;
            }
            else
            {
                textBox_IP.text = string.Empty;
                if (ipList[0].ToString() == "127.0.0.1")
                {
                    //表示没有网络连接
                    textBox_IP.text = textBox_IP.text + ipList[0].ToString()+ "\n";
                    return null;
                }
                //计数器，判断有几个192.168打头的ip
                int num = 0;
                for (int i = 0; i < ipList.Length; i++)
                {
                    if (ipList[i].ToString().StartsWith("192.168"))
                    {
                        textBox_IP.text = textBox_IP.text + ipList[0].ToString() + "\n";

                        num += 1;
                    }
                }
                if (num == ipList.Length)
                {
                    //全部都是192.168打头的
                    return false;
                }
                else
                {
                    //有不是192.168打头的ip，要进一步查询是否是GPRS连接
                    return true;
                }

            }

        }*/
    }
}
