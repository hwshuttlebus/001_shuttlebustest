﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Reflection;
using System.IO;
using System.Xml;
using Microsoft.Win32;

namespace WincePda
{
    public class UIInfo
    {
        private static Hashtable ht_ControlName =null;//存放单个窗体的控件名称
        public static LanguageType languaeType = LanguageType.Unknown;
        public static Hashtable ControlsName = new Hashtable();//存放所有窗体的控件名称
        /// <summary>
        /// 语言类型
        /// </summary>
        public enum LanguageType
        {
            CN,             //中文
            EN,             //英文
            Unknown         //未知
        }
        /// <summary>
        /// 得到语言类型
        /// 中文：2052
        /// 英文：1033
        /// </summary>
        /// <returns></returns>
        public static void GetLanguageType()
        {
            try
            {
                if ((int)Registry.GetValue("HKEY_LOCAL_MACHINE\\nls", "DefaultLCID", 0) == 2052)
                    languaeType = LanguageType.CN;
                else
                    languaeType = LanguageType.EN;
            }
            catch
            { }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ModeType">模块类型</param>
        /// <param name="FormName">窗体名称</param>
        public  static void GetControlName(string ModeType, string FormName)
        {
            if (ControlsName[FormName] != null)
                return;
            GetLanguageType();
            string applicationPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase);//获取本地运行路径 
            string xmlname = "UIConfigFile.xml";
            try
            {

                if (File.Exists(applicationPath + "\\" + xmlname))
                {

                    XmlDocument doc = new XmlDocument();
                    doc.Load(applicationPath + "\\" + xmlname);
                    XmlNode node = doc.DocumentElement.SelectSingleNode(string.Format("/Root/{0}/{1}/Form[@FormName='{2}']", ModeType, languaeType, FormName));//获取指定的节点
                    XmlNodeList xlist = node.ChildNodes;
                    ht_ControlName = new Hashtable();
                    ht_ControlName.Clear();
                    foreach (XmlNode xn in xlist)
                    {
                        ht_ControlName.Add(xn.Name, xn.InnerText);
                    }
                    ControlsName.Add(FormName, ht_ControlName);
                 }
            }
            catch (Exception e)
            {

            }
        }
        /// <summary>
        /// 得到控件名称
        /// </summary>

        public class ControlName
        {
            /// <summary>
            /// 获取指定的键相关联的值。
            /// </summary>
            /// <param name="key">要获取或设置其值的键</param>
            /// <returns>与指定的键相关联的值。如果未找到指定的键则返回string.Empty</returns>
            public string this[object key,string FormName]
            {
                get
                {
                    try
                    {
                        return ((Hashtable)ControlsName[FormName])[key].ToString();//ht_ControlName[key].ToString();
                    }
                    catch (System.Exception ex)
                    {
                        return "";
                    }
                }
            }
        }
        
    }
}
