﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;


namespace WincePda.Chinese.GPS
{
    public partial class GpsDemo : Form
    {
        #region 
           private UIInfo.ControlName controlName = new UIInfo.ControlName();
            double beginTime = 0;
            double endTime = 0;
            CLR_GPS myGPS;       
        #endregion



#region  socket
            private IPAddress myIP;
            private IPEndPoint MyServer;
            private Socket MySocket;
            private bool isOpen = false;//状况状态

            CLR_GPS.gpsItem gpsData=new CLR_GPS.gpsItem();

            /// <summary>
            /// 记录接收到的字节内容
            /// </summary>
            public static List<byte> data_Recs = new List<byte>();

            /// <summary>
            /// 保存串口接收到的字符串
            /// </summary>
            private string strReceive = string.Empty;

            /// <summary>
            /// 服务器IP地址,此地址不是固定不变的，要从agps.u-blox.com解析出来
            /// </summary>
            private string ip_str = "";
            /// <summary>
            /// 服务器端口号
            /// </summary>
            private int port = 46434;
#endregion
        public GpsDemo()
        {
            InitializeComponent();
            CLR_Regex.GetSystemVersion();
            initGpsData();
            myGPS = new CLR_GPS();
            myGPS.PowerOn();
            UIInfo.GetControlName("GPS", "GPS");
            InitializationControlsName();
        }


        /// <summary>
        /// 获取指定url的IP地址,如果获取失败，返回空字符串
        /// </summary>
        /// <param name="url"></param>
        private string getServerIP(string url)
        {
            try
            {
                IPHostEntry hostInfo = Dns.GetHostEntry(url);
                //string hostName = System.Net.Dns.GetHostName();
                //System.Net.IPHostEntry myIp = System.Net.Dns.GetHostEntry(hostName);
                return hostInfo.AddressList[0].ToString();
            }
            catch (System.Exception)
            {
                return string.Empty;
            }
        }
        


        /// <summary>
        /// 初始化GPS数据
        /// </summary>
        private void initGpsData()
        {
            gpsData.allSatellite = "0";
            gpsData.altitude = "0";
            gpsData.currDate = "00-00-00";
            gpsData.lati = 0.0F;
            gpsData.longi = 0.0F;
            gpsData.useSatellite = "0";
            gpsData.UTC_time = "000000";

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //if (CLR_Regex.pdaDeviceType == CLR_Regex.PDADeviceType.C3000)
            //    serialPort1.PortName = "COM7";
            //else
            //    serialPort1.PortName = "COM4";
  
        }

           

        private void btnGet_Click(object sender, EventArgs e)
        {
            initGpsData();
            try
            {
                if(myGPS.Gps_OpenSerial())
                isOpen = true;
            }
            catch (System.Exception )
            {
                MessageBox.Show(controlName["MSG_1","GPS"]); // ("串口无法正常打开，请检查串口是否被占用");
                return;
            }

            btnStop.Enabled = true;

            btnGet.Enabled = false;

            btnStop.Focus();

            currState = 0;
            timer1.Enabled = true;
            beginTime = Environment.TickCount;
            textBoxBeginTime.Text = Convert.ToString(System.DateTime.Now.TimeOfDay.ToString());
            textBoxAccess.Text = string.Empty;
            textBoxSpend.Text = string.Empty;
            timerShowData.Enabled = true;
        }

      

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                myGPS.Gps_CloseSerial();
                isOpen = false;
            }
            catch (System.Exception )
            {
            	
            }
      
            btnGet.Enabled = true;

            btnStop.Enabled = false;

            btnGet.Focus();
       
        }
           
        private void MainForm_Closed(object sender, EventArgs e)
        {
            //释放GPS资源         
            timer1.Enabled = false;
            timer1.Dispose();
            timerTcp.Enabled = false;
            timerTcp.Dispose();
            timerShowData.Enabled = false;
            timerShowData.Dispose();
        }

     
        private void button1_Click(object sender, EventArgs e)
        {
            myGPS.PowerOff();
            if (btnStop.Enabled)
            {
                btnStop_Click(null, null);
                Thread.Sleep(100);
            }
            this.Close();
        }



        /// <summary>
        /// 标记当前状态  1为在等待TCP回传数据  0为要向服务器发送当前地址信息  2表示要向GPS模块发送数据
        /// </summary>
        int currState = 0;

        /// <summary>
        /// 计时
        /// </summary>
        int num_timer = 0;


      

        /// <summary>
        /// 记录接收到的回传字符
        /// </summary>
        string dataRecStr = string.Empty;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (currState==0)
            {
                string commandText = "cmd=aid;";
                commandText += "user=chainwaypan@chainway.cn;";
                commandText += "pwd=Mrubj;";
                //输入默认纬度信息
                commandText += "lat=22.21;";
                //输入默认经度信息
                commandText += "lon=114.11;";
                //输入默认搜索半径
                commandText += "pacc=100000\r\n";

                try
                {
                    ip_str = getServerIP("agps.u-blox.com");
                    if (ip_str.Length>0)
                    {
                        myIP = IPAddress.Parse(ip_str);
                        MyServer = new IPEndPoint(myIP, port);
                        MySocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        MySocket.Connect(MyServer);

                        data_Recs.Clear();
                        byte[] data = Encoding.ASCII.GetBytes(commandText);
                        //发送本地信息
                        dataRecStr = string.Empty;
                        MySocket.Send(data);
                        timerTcp.Enabled = true;
                        num_timer = 0;
                        currState = 1;
                    }
                    else
                    {
                        //获取不到服务器的IP,则关闭时钟
                        timer1.Enabled = false;
                    }
                }
                catch (System.Exception)
                {
                    //表示当前没有联网
                    timer1.Enabled = false;
                }
            }       
            else if (currState==1)
            {
                if (num_timer<4)
                {
                    num_timer += 1;
                    return;
                }
                else
                {
                    timer1.Enabled = false;
                    if (dataRecStr.Contains("application/ubx"))
                    {
                        byte[] dataSend = data_Recs.ToArray();
                        bool res = SendData(dataSend);
                        //pcSqlite.myFile.Add_New_Note("\\a.txt", "Send A-GPS OK");
                    }
                }
            }
            else
            {
                timer1.Enabled = false;
            }
                    
           
        }

        /// <summary>
        /// 串口发送数据
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool SendData(byte[] data)
        {
            try
            {
                   // serialPort1.Write(data, 0, data.Length);
                myGPS.Gps_SendData(data,data.Length);
                return true;
            }
            catch (System.Exception)
            {
            
                return false;
            }
        }


        private void timerTcp_Tick(object sender, EventArgs e)
        {
            try
            {
                byte[] receiveBytes = new byte[1024];
                string sR = string.Empty;
                if (MySocket.Poll(100, SelectMode.SelectRead))
                {
                    int successReceiveBytes = MySocket.Receive(receiveBytes);
                    if (successReceiveBytes < 1)
                    {
                        return;
                    }

                    byte[] dataR = new byte[successReceiveBytes];
                    for (int i = 0; i < dataR.Length; i++)
                    {
                        dataR[i] = receiveBytes[i];
                    }
                    for (int k = 0; k < dataR.Length; k++)
                    {
                        data_Recs.Add(dataR[k]);
                    }
                    string dr = Encoding.ASCII.GetString(dataR, 0, dataR.Length);

                    //pcSqlite.myFile.Add_New_Note("\\aaa.txt", dr);

                    dataRecStr = dataRecStr + dr;
                    //pcSqlite.myFile.Add_New_Note("agpsData.txt", BitConverter.ToString(dataR, 0, dataR.Length) + "-");
                }
            }
            catch (System.Exception)
            {
                timer1.Enabled = false;
            }
        }



     
    
        private void timerShowData_Tick(object sender, EventArgs e)
        {
            #region 得到数据串口返回的数据
            try
            {
                if (isOpen)
                {
                    byte[] byteData = new byte[1024];
                    myGPS.Gps_ReceiveData(byteData, byteData.Length);
                   // WriteFile(byteData);
                    strReceive = Encoding.ASCII.GetString(byteData, 0, byteData.Length);
                    myGPS.AnalysisGPSData(strReceive, ref gpsData);
                }
            }
            catch (System.Exception ex)
            {

            }
            #endregion


            textBoxDate.Text = gpsData.currDate;
            textBoxTime.Text = gpsData.UTC_time.Substring(0,2)+":"+gpsData.UTC_time.Substring(2,2)+":"+gpsData.UTC_time.Substring(4,2);
            //time.Substring(0, 2) + ":" + time.Substring(2, 2) + ":" + time.Substring(4, 2);
            textBoxAll.Text = gpsData.allSatellite;
            textBoxsatellite.Text = gpsData.useSatellite;

            if (string.IsNullOrEmpty(textBoxAccess.Text))
            {
                if (gpsData.lati != 0.0F && gpsData.longi != 0.0F)
                {
                    textBoxAccess.Text = Convert.ToString(System.DateTime.Now.TimeOfDay.ToString());
                    endTime = Environment.TickCount;
                    int passTime = (int)((endTime - beginTime) / 1000);
                    textBoxAccess.Text = (textBoxBeginTime.Text == textBoxAccess.Text) ? (Convert.ToDateTime(textBoxBeginTime.Text).AddSeconds(1)).ToString("HH:mm:ss"): textBoxAccess.Text;
                    textBoxSpend.Text = (passTime==0?"1":passTime.ToString());

                }
            }

           
            textBoxLa.Text = gpsData.lati.ToString();
            textBoxLo.Text = gpsData.longi.ToString();
        }
        public void InitializationControlsName()
        {
            this.Text = controlName["FormText", "GPS"];
            labelDate.Text = controlName["labelDate", "GPS"];
            labelAll.Text = controlName["labelAll", "GPS"];
            labelBegin.Text = controlName["labelBegin", "GPS"];
            labelUsed .Text = controlName["labelUsed", "GPS"];
            labelAccess .Text = controlName["labelAccess", "GPS"];
            labelLo.Text = controlName["labelLo", "GPS"];
            labelSpend.Text = controlName["labelSpend", "GPS"];
            labelLa.Text = controlName["labelLa", "GPS"];
            labelSecond.Text = controlName["labelSecond", "GPS"];
            btnGet.Text = controlName["btnGet", "GPS"];
            btnStop.Text = controlName["btnStop", "GPS"];
            labelCurr.Text = controlName["labelCurr", "GPS"];
        }

/*
        private void WriteFile(byte[] data)
        {
            try
            {

                string path =System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)+"\\GetGPS.txt";
                 System.IO.FileStream f = new System.IO.FileStream(path,System.IO.FileMode.Append,System.IO.FileAccess.Write,System.IO.FileShare.Write);
                f.Write(data,0,data.Length);
                System.IO.StreamWriter sw = new System.IO.StreamWriter(f);
                sw.WriteLine("\r\n"+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sw.Close();
                f.Close();
            }
            catch (System.Exception ex)
            {
            	
            }
       
        }
 * */
    }
}